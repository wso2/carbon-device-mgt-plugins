__author__ = 'lasantha'

import os
import shutil
import signal
import start_up
import sequence_runner
from subprocess import check_output
from lxml import etree
import time
import logging
import kernel_utils
import subprocess
import urllib

LOGGER = logging.getLogger('wso2server.resource_types')


class DisplayAdmin():

    cont_conf_path = "../resources/conf/digital_display_content.xml"
    path_array = []

    def __init__(self):
        LOGGER.info("Admin Panel Created")

    # shutdown process for given process name
    def shutdown_process(self, name):
        pid = self.get_pid(name).replace('\n', '').split(" ")
        for x in pid:
            os.kill(int(x), signal.SIGKILL)

    # kill python process
    def terminate_display(self):
        try:
            self.shutdown_process("python")
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    def terminate_server(self):
        start_up.ContentUtilityClass().terminate_server()

    def start_server(self):
        start_up.ContentUtilityClass().start_server(kernel_utils.web_content_path)

    def restart_server(self):
        try:
            self.terminate_server()
            self.start_server()
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    def restart_display(self):
        try:
            subprocess.Popen("sudo reboot", shell=True)
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    def start_browser(self):
        start_up.ContentUtilityClass().open_browser()

    def close_browser(self):
        start_up.ContentUtilityClass().close_browser()

    def restart_browser(self):
        try:
            self.close_browser()
            self.start_browser()
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    def get_pid(self, name):
        return check_output(["pidof", name])

    # upload file(html, image, js, css) to /resources/www folder
    def upload_content(self, remote_path, folder_name):
        try:
            download_file = urllib.URLopener()
            download_file.retrieve(remote_path, '../resources/www/'+folder_name+"/"+remote_path.split('/')[-1])
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    # read content config xml file
    def read_conf(self):
        # XMLParser parameters----->>> ns_clean=True,remove_comments=True,remove_blank_text=True
        parser = etree.XMLParser()
        tree = etree.parse(self.cont_conf_path, parser)
        return tree

    # change running sequence list
    def change_sequence_list(self):
        start_up.ContentUtilityClass().set_resources_conf()
        seq_runner = sequence_runner.SequenceRunner()
        seq_runner.set_current_resources_conf(start_up.ContentUtilityClass().get_resources_conf())
        seq_runner.set_sequence()

    # edit content config xml file
    def edit_content_config(self, page_no, attr, new_val):
        try:
            tree = self.read_conf()
            root = tree.getroot()
            nsp = root.nsmap
            # read content xml file and append displaying path set to path_array
            self.build_path_array()
            # iterate through xml file
            for elem in root.iter():
                if elem.tag == '{'+nsp[None]+'}'+'Resource' and elem.attrib['path'] == self.path_array[int(page_no)-1]:
                    elem.set(attr, new_val)
                    break

            tree.write(self.cont_conf_path)
            self.change_sequence_list()
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    # create child resource
    def build_resource(self, type_, time_, path_):
        child = etree.Element('Resource')
        child.set('type', type_)
        child.set('time', time_)
        child.set('path', path_)
        return child

    # read content conf xml and update path_array
    def build_path_array(self):
        tree = self.read_conf()
        root = tree.getroot()
        nsp = root.nsmap
        array = []

        for elem in root.iter():
            if elem.tag == '{'+nsp[None]+'}'+'Resource':
                array.append(elem.attrib['path'])

        self.path_array = array

    # add new resource to content conf xml file
    def add_new_resource(self, *args):
        try:
            # if type is folder type create folder in /resource/www path and name it as path name
            if args[0] == "folder":
                newpath = '../resources/www/'+args[2]
                if not os.path.exists(newpath):
                    os.makedirs(newpath)

            tree = self.read_conf()
            root = tree.getroot()
            nsp = root.nsmap

            # default
            if len(args) == 3:
                for elem in root.iter():
                    if elem.tag == '{'+nsp[None]+'}'+'DisplaySequence':
                        child = self.build_resource(args[0], args[1], args[2])
                        elem.append(child)
                        break
            # if user want to add resource into specific place
            elif len(args) == 4:
                self.build_path_array()
                if "before=" in args[3]:
                    for elem in root.iter():
                        if elem.tag == '{'+nsp[None]+'}'+'Resource' and elem.attrib['path'] == self.path_array[int(args[3].split('=')[1])-1]:
                            child = self.build_resource(args[0], args[1], args[2])
                            elem.addprevious(child)
                            break
                elif "after=" in args[3]:
                    for elem in root.iter():
                        if elem.tag == '{'+nsp[None]+'}'+'Resource' and elem.attrib['path'] == self.path_array[int(args[3].split('=')[1])-1]:
                            child = self.build_resource(args[0], args[1], args[2])
                            elem.addnext(child)
                            break

            tree.write(self.cont_conf_path)
            self.change_sequence_list()
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    # remove resource from cont conf xml file
    def remove_resources(self, page_no):
        try:
            tree = self.read_conf()
            root = tree.getroot()
            nsp = root.nsmap
            self.build_path_array()
            for elem in root.iter():
                if elem.tag == '{'+nsp[None]+'}'+'DisplaySequence':
                    for re in elem.iter():
                        if re.tag == '{'+nsp[None]+'}'+'Resource' and re.attrib['path'] == self.path_array[int(page_no)-1]:
                            re.getparent().remove(re)
                            break

            tree.write(self.cont_conf_path)
            self.change_sequence_list()
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    def remove_empty_dir(self, dir_name):
        try:
            os.rmdir('../resources/www/'+dir_name)
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    # remove folder in /resources/www path include files in folder
    def remove_dir_and_content(self, dir_name):
        try:
            shutil.rmtree('../resources/www/'+dir_name)
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    # remove files in /resources/www/page... path
    def remove_file(self, dir_name, file_name):
        try:
            os.remove('../resources/www/'+dir_name+'/'+file_name)
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"

    # when server ping the device call to this function
    def get_status(self):
        try:
            return "Success"
        except Exception as e:
            LOGGER.warning("Exception"+str(e))
            return "Failed"






